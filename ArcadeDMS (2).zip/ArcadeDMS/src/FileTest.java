import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import java.nio.file.Files;
import org.junit.jupiter.api.BeforeEach;
import java.time.LocalDate;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class FileTest {
    @BeforeEach
    void setUp() {
        ArcadeDMS arcadedms = new ArcadeDMS();
    }



    @Test
    @DisplayName("File Test")
    void testFileLoading() throws IOException {
        // Create temp file
        File tempFile = File.createTempFile("arcadeTest", ".txt");

        FileWriter writer = new FileWriter(tempFile);
        writer.write("12345 - Micah - 2026-02-14 - 10 - 50\n");
        writer.close();

        ArcadeDMS dms = new ArcadeDMS();

        // Simulate reading file manually
        List<String> lines = Files.readAllLines(tempFile.toPath());

        assertFalse(lines.isEmpty());
        assertTrue(lines.get(0).contains("Micah"));

        tempFile.delete(); // cleanup
    }
}